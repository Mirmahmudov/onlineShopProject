import React from 'react'

function Modal() {
  return (
    <div>Modal</div>
  )
}

export default Modal