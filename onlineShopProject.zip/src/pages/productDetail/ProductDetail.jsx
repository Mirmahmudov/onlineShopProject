import React from 'react'

function ProductDetail() {
  return (
    <div>ProductDetail</div>
  )
}

export default ProductDetail